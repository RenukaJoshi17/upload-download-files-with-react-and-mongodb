const mongoose = require('mongoose');

const fileSchema = mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true
    },
    description: {
      type: String,
      required: true,
      trim: true
    },
    file_path: {
      type: String,
      required: true
    },
    file_mimetype: {
      type: String,
      required: true
    }
  },
  {
    timestamps: true
  }
);

const File = mongoose.model('File', fileSchema);

module.exports = File;

//*Here, we have defined the schema for the collection as we're using multer library to work with MongoDB. 
//*We will be storing the title, description, 
//*file_path and file_mimetype in the collection so we have described the type of each in this file.