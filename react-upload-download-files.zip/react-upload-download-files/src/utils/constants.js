//!Calling API for file upload
//? Starting our express server on port 3030
export const API_URL = 'http://localhost:3030';